# depth-tomato-2 > 2024-06-02 9:31pm
https://universe.roboflow.com/emre-y-6y8kx/depth-tomato-2

Provided by a Roboflow user
License: CC BY 4.0

